#define BOOST_TEST_MODULE thrift
#include <boost/test/included/unit_test.hpp>
