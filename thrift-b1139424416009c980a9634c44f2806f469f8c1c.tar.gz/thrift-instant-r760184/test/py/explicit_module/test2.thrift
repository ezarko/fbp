include "test1.thrift"

struct another {
  1: test1.astruct something;
}
