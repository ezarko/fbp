<?php
$GEN_DIR = 'gen-phpi';
$MODE = 'inline';
include_once('TestClient.php');
?>
