const i64 myint = 68719476736
const i64 broken = 9876543210987654321  // A little over 2^63

enum foo {
  bar = 68719476736
}
