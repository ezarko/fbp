namespace rb ThriftBenchmark

service BenchmarkService {
  i32 fibonacci(1:byte n)
}
